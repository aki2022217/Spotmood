// 環境変数を読み込む
require('dotenv').config();

// Spotify情報を環境変数から取得
const clientId = process.env.SPOTIFY_CLIENT_ID;
const clientSecret = process.env.SPOTIFY_CLIENT_SECRET;
const redirectUri = process.env.SPOTIFY_REDIRECT_URI;

const express = require("express");
const axios = require("axios");
const cors = require("cors");
require("dotenv").config();

const app = express();
app.use(cors());
app.use(express.json());

const clientId = process.env.SPOTIFY_CLIENT_ID;
const clientSecret = process.env.SPOTIFY_CLIENT_SECRET;
const redirectUri = process.env.SPOTIFY_REDIRECT_URI;

// Spotify認証コード交換用エンドポイント
app.get("/auth", async (req, res) => {
  const code = req.query.code;
  if (!code) return res.status(400).send("codeが必要です");

  try {
    const resp = await axios.post("https://accounts.spotify.com/api/token", new URLSearchParams({
      grant_type: "authorization_code",
      code,
      redirect_uri: redirectUri,
      client_id: clientId,
      client_secret: clientSecret
    }).toString(), {
      headers: { "Content-Type": "application/x-www-form-urlencoded" }
    });
    res.json(resp.data); // access_token, refresh_token, expires_in
  } catch (err) {
    console.error(err.response?.data || err.message);
    res.status(500).json({ error: "Spotify token error" });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
